curl openinterpreter.com/cli | sh
interpreter